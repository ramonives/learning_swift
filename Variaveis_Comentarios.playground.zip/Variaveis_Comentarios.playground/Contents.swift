import UIKit

//Existem dois modelos de variável no SWIFT


// var é uma variável mutável para armazenar dados
var message = "Ola mundo!!!"
message = "Ola Ramon" //alterando estado do message

// let (constante) é uma variável imutável para armazenar dados
let name = "Ramon" //let nao pode ser alterado

print(name)


// comentarios de uma linha usa-se // ->
// ptint("Ola Mundo")

//comentarios de mais de uma linha usa-se ->
/*
 comentarios
 de multi
 linhas
 */
