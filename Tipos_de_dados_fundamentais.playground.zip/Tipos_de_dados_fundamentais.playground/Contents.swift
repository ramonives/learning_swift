import UIKit

// TIPOS DE DADOS

let int = 1 // Int -> Inteiros
let double = 3.14 // Double -> numeros decimais ou numeros flutuantes
let string = "Ramon" // String -> textos
let isDriver = false // Bool -> verdadeiro ou false | true or false


// Tipando as variaveis
let number: Int = 2
let pi: Double = 3.14
let name: String = "Ramon"
let isDeveloper: Bool = true
