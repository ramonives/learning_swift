import UIKit

// INCREMENTOS, OPERADOES LOGICOS

let result = 2 > 3

let x = 10
let y = 20
let res = x == y
let res2 = x != y

let firstName = "Ramon"
let lastName = "Ives"
let res3 = firstName > lastName //R vem depois de I entao ele retorna true

/*
 
 == , != , = , < , <= , > , >= , ! , && , ||
 
 */

let isDriver = false
let isStudent = true

!isDriver

let res4 = isDriver || isStudent
print(res4)


let res5 = isDriver && isStudent
print(res5)
